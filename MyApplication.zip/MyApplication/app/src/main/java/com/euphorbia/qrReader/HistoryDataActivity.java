package com.euphorbia.qrReader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class HistoryDataActivity extends AppCompatActivity {


    private final String dbName = "qrDB.db";
    private final String tableName = "qrList";

    SQLiteDatabase ReadDB;

    private EditText editText;
    private TextView tv;
    private ImageButton ib;
    private Button confirm, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_data);

        final ArrayList<Data> list = new ArrayList<>();

        ReadDB = this.openOrCreateDatabase(dbName, MODE_PRIVATE, null);

        editText = findViewById(R.id.editText);
        tv = findViewById(R.id.tv1);
        ib = findViewById(R.id.DeleteBtn);
        confirm = findViewById(R.id.confirm1);
        cancel = findViewById(R.id.cancel1);

        Data data = (Data) getIntent().getSerializableExtra("data");
        final int idx = getIntent().getIntExtra("position", 0) + 1;

        editText.setText(data.getTitle());
        tv.setText(data.getContent());

        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ReadDB.execSQL("DELETE FROM " + tableName + " WHERE idx = '" + idx + "';");

                Intent intent = new Intent();
                setResult(RESULT_OK,intent);
                finish();

            }
        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String title = editText.getText().toString();

                ReadDB.execSQL("UPDATE " + tableName + " SET title = '" + title + "' WHERE idx = '" + idx + "';");

                Intent intent = new Intent();
                setResult(RESULT_OK,intent);
                finish();

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();

            }
        });

    }
}
